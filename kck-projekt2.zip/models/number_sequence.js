const numberSequenceModel = {
    randomNumber: null,
    time: 1000,
    sequenceLength: 1,
};

module.exports = numberSequenceModel;
