const simonSaysModel = {
    sequence: [],
    index: 0,
    counter: 0,
    randomNumber: 0
};

module.exports = simonSaysModel;
